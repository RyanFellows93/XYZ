package Models;

import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author r2-fellows
 */
public class Members {
       
    ArrayList<String> id;
    ArrayList<String> name;
    ArrayList<String> address;
    ArrayList<String> dob;      //date of birth
    ArrayList<String> dor;      //date of registration 
    ArrayList<String> status;   //applied or not
    ArrayList<Integer> balance;
    int CustomerSize;
   
    public Members() throws SQLException {
        name = Jdbc.runQuery("SELECT * FROM members", "name");

        id = Jdbc.runQuery("SELECT * FROM members", "id");

        address = Jdbc.runQuery("SELECT * FROM members", "address");
        
        dob = Jdbc.runQuery("SELECT * FROM members", "dob");
        
        dor = Jdbc.runQuery("SELECT * FROM members", "dor");
        
        status = Jdbc.runQuery("SELECT * FROM members", "status");
        
        balance = Jdbc.runQuery("SELECT * FROM members", "balance");
        
        CustomerSize = id.size();
        
        
    }

    public String getId(int index) throws SQLException {

        id = Jdbc.runQuery("SELECT * FROM members", "id");
        String individual_id = id.get(index);

        return individual_id;
    }


    public String getName(int index) throws SQLException {
       name = Jdbc.runQuery("SELECT * FROM members", "name");
        String individual_name = name.get(index);

        return individual_name;
    }


    public String getAddress(int index) throws SQLException {
    address = Jdbc.runQuery("SELECT * FROM members", "address");
        String individual_address = address.get(index);

        return individual_address;   
    }


    public String getDob(int index) throws SQLException {
        dob = Jdbc.runQuery("SELECT * FROM members", "dob");
        String individual_dob = dob.get(index);

        return individual_dob;
    }

    public String getDor(int index) throws SQLException {
     dor = Jdbc.runQuery("SELECT * FROM members", "dor");
        String individual_dor = dor.get(index);

        return individual_dor;
    }


    public String getStatus(int index) throws SQLException {
       status = Jdbc.runQuery("SELECT * FROM members", "status");
        String individual_status = status.get(index);

        return individual_status;
    }


    public int getBalance(int index) throws SQLException {
        balance = Jdbc.runQuery("SELECT * FROM members", "balance");
        int individual_balance = balance.get(index);

        return individual_balance;
    }
    
//      //add customer
//    public void addMember(String member, String address) throws SQLException {
//        if (name.contains(member)) {
//        } else {
//            Jdbc.runUpdate("INSERT INTO customer (name, address) VALUES('" + member + "', '" + address + "')");
//        }
//    }


//    //get customer table size
//    public int getCustomerSize() throws SQLException {
//        id = Jdbc.runQuery("SELECT * FROM customer", "id");
//        return this.id.size();
//    }
    
}
